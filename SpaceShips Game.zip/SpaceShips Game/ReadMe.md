--------------------------------------------------------------------------------------------------
How to start the game?
R: double click the HTML File

credits:
CodigoMentor-Base
KL9X0-Addons and Fix errors
---------------------------------------------------------------------------------------------------
This is a “Game” Open Source 